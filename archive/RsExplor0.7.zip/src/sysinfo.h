#ifndef SYSINFO_H
#define SYSINFO_H

#include "common.h"

// 弹出一个浮动窗口显示系统信息（CPU 和内存），按 q 或 ESC 退出
void show_sysinfo_popup(void);

#endif // SYSINFO_H

